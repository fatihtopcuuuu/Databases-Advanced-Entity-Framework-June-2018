﻿namespace PetClinic.DataProcessor.Dtos.Import
{
    using System.ComponentModel.DataAnnotations;
    using System.Xml.Serialization;

    [XmlType("AnimalAid")]
    public class ProcedureAnimalAidDto
    {
        [Required]
        public string Name { get; set; }
    }
}