﻿namespace PetClinic.DataProcessor
{
    using System;
    using AutoMapper;
    using Data;
    using Dtos.Import;
    using Models;
    using Newtonsoft.Json;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.Globalization;
    using System.IO;
    using System.Linq;
    using System.Text;
    using System.Xml.Linq;
    using System.Xml.Serialization;
    using ValidationContext = System.ComponentModel.DataAnnotations.ValidationContext;

    public class Deserializer
    {
        private const string FailureMessage = "Error: Invalid data.";
        private const string SuccessMessage = "Record {0} successfully imported.";

        public static string ImportAnimalAids(PetClinicContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var deserializedAnimalAids = JsonConvert.DeserializeObject<AnimalAidDto[]>(jsonString);

            var validAnimalAids = new List<AnimalAid>();
            foreach (var animalAidDto in deserializedAnimalAids)
            {
                var animalExists = validAnimalAids.Any(a => a.Name == animalAidDto.Name);
                if (!IsValid(animalAidDto) || animalExists)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                var animalAid = Mapper.Map<AnimalAid>(animalAidDto);
                validAnimalAids.Add(animalAid);

                sb.AppendLine(string.Format(SuccessMessage, animalAidDto.Name));
            }
            context.AnimalAids.AddRange(validAnimalAids);
            context.SaveChanges();

            return sb.ToString();
        }

        public static string ImportAnimals(PetClinicContext context, string jsonString)
        {
            var sb = new StringBuilder();

            var deserializedAnimals = JsonConvert.DeserializeObject<AnimalDto[]>(jsonString);

            var validAnimals = new List<Animal>();
            foreach (var animalDto in deserializedAnimals)
            {
                var passportAlreadyExists = context.Passports.Any(p => p.SerialNumber == animalDto.Passport.SerialNumber);

                if (!IsValid(animalDto) || !IsValid(animalDto.Passport) || passportAlreadyExists)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                var animal = Mapper.Map<Animal>(animalDto);
                validAnimals.Add(animal);

                sb.AppendLine($"Record {animal.Name} Passport №: {animal.Passport.SerialNumber} successfully imported.");
            }
            context.Animals.AddRange(validAnimals);
            context.SaveChanges();

            return sb.ToString();
        }

        public static string ImportVets(PetClinicContext context, string xmlString)
        {
            var sb = new StringBuilder();

            var serializer = new XmlSerializer(typeof(VetDto[]), new XmlRootAttribute("Vets"));
            var deserializedVets = (VetDto[])serializer.Deserialize(new MemoryStream(Encoding.UTF8.GetBytes(xmlString)));

            var validVets = new List<Vet>();
            foreach (var vetDto in deserializedVets)
            {
                var vetPhoneNumberExists = validVets.Any(v => v.PhoneNumber == vetDto.PhoneNumber);
                if (!IsValid(vetDto) || vetPhoneNumberExists)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                var vet = Mapper.Map<Vet>(vetDto);
                validVets.Add(vet);

                sb.AppendLine(string.Format(SuccessMessage, vet.Name));
            }
            context.Vets.AddRange(validVets);
            context.SaveChanges();

            return sb.ToString();
        }

        public static string ImportProcedures(PetClinicContext context, string xmlString)
        {
            var xDoc = XDocument.Parse(xmlString);
            var elements = xDoc.Root.Elements();

            var sb = new StringBuilder();
            var validEntries = new List<Procedure>();

            foreach (var el in elements)
            {
                string vetName = el.Element("Vet")?.Value;
                string passportId = el.Element("Animal")?.Value;
                string dateTimeString = el.Element("DateTime")?.Value;

                int? vetId = context.Vets.SingleOrDefault(v => v.Name == vetName)?.Id;
                bool passportExists = context.Passports.Any(p => p.SerialNumber == passportId);

                bool dateIsValid = DateTime
                    .TryParseExact(dateTimeString, "dd-MM-yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out DateTime dateTime);

                var animalAidElements = el.Element("AnimalAids")?.Elements();

                if (vetId == null || !passportExists || animalAidElements == null || !dateIsValid)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                var animalAidIds = new List<int>();
                bool allAidsExist = true;

                foreach (var aid in animalAidElements)
                {
                    string aidName = aid.Element("Name")?.Value;

                    int? aidId = context.AnimalAids.SingleOrDefault(a => a.Name == aidName)?.Id;

                    if (aidId == null || animalAidIds.Any(id => id == aidId))
                    {
                        allAidsExist = false;
                        break;
                    }

                    animalAidIds.Add(aidId.Value);
                }

                if (!allAidsExist)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                var procedure = new Procedure
                {
                    VetId = vetId.Value,
                    AnimalId = context.Animals.Single(a => a.PassportSerialNumber == passportId).Id,
                    DateTime = dateTime,
                };

                foreach (var id in animalAidIds)
                {
                    var mapping = new ProcedureAnimalAid
                    {
                        Procedure = procedure,
                        AnimalAidId = id
                    };

                    procedure.ProcedureAnimalAids.Add(mapping);
                }

                bool isValid = IsValid(procedure);

                if (!isValid)
                {
                    sb.AppendLine(FailureMessage);
                    continue;
                }

                validEntries.Add(procedure);
                sb.AppendLine("Record successfully imported.");
            }
            context.Procedures.AddRange(validEntries);
            context.SaveChanges();

            string result = sb.ToString().TrimEnd();
            return result;
        }

        private static bool IsValid(object obj)
        {
            var context = new ValidationContext(obj);
            var result = new List<ValidationResult>();

            var isValid = Validator.TryValidateObject(obj, context, result);
            return isValid;
        }
    }
}
